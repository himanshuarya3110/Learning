package middlewares

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"

	// "library/middleware" // Update with your actual import path
	// "library/utils"      // Assuming utils contains RespondJSON and ParseToken
	"library/config" // Assuming config.ConnectTestDB and config.DB are your DB connections
	"library/models" // Assuming your Session model is in the models package
)

func setupTestDB() {
	// Connect to the test database
	config.ConnectDBTest()

	// Ensure the Session table is created
	// config.AutoMigrate(&models.Session{})

	// Clean up the table before each test
	config.DB.Exec("DELETE FROM sessions")

	// Insert dummy session data
	session := models.Session{
		UserID:    1,
		Token:     "valid-jwt-token", // Dummy token
		ExpiresAt: time.Now().Add(24 * time.Hour),
		IsActive:  true,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}
	config.DB.Create(&session)
}

func TestAuthMiddleware(t *testing.T) {
	// Setup test DB with dummy session data
	setupTestDB()

	// Setup Gin and mock requests
	gin.SetMode(gin.TestMode)

	// Mock response recorder
	w := httptest.NewRecorder()

	// Setup router and middleware
	r := gin.Default()
	r.Use(AuthMiddleware())

	// Example route for testing
	r.GET("/protected", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"message": "You are authorized"})
	})

	// Create a mock request with a valid token
	req, _ := http.NewRequest(http.MethodGet, "/protected", nil)
	req.Header.Set("Authorization", "Bearer valid-jwt-token") // Valid token

	// Perform the request
	r.ServeHTTP(w, req)

	// Assert the response status code and message
	assert.Equal(t, http.StatusOK, w.Code)
	assert.Contains(t, w.Body.String(), "You are authorized")
}

func TestAuthMiddleware_Unauthorized(t *testing.T) {
	// Setup test DB with dummy session data
	setupTestDB()

	// Setup Gin and mock requests
	gin.SetMode(gin.TestMode)

	// Mock response recorder
	w := httptest.NewRecorder()

	// Setup router and middleware
	r := gin.Default()
	r.Use(AuthMiddleware())

	// Example route for testing
	r.GET("/protected", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"message": "You are authorized"})
	})

	// Create a mock request with an invalid token
	req, _ := http.NewRequest(http.MethodGet, "/protected", nil)
	req.Header.Set("Authorization", "Bearer invalid-jwt-token") // Invalid token

	// Perform the request
	r.ServeHTTP(w, req)

	// Assert the response status code and message for unauthorized request
	assert.Equal(t, http.StatusUnauthorized, w.Code)
	assert.Contains(t, w.Body.String(), "Session expired or invalid")
}
