# Link

https://medium.com/@rashid14713524/a-simple-todo-crud-api-using-golang-gin-gorm-and-postgresql-981a9bde0c4d

https://www.bacancytechnology.com/blog/golang-jwt

https://auth0.com/blog/authentication-in-golang/

https://app.studyraid.com/en/read/5926/130188/working-with-cookies